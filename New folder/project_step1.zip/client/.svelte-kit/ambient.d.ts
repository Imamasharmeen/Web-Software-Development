
// this file is generated — do not edit it


/// <reference types="@sveltejs/kit" />

/**
 * Environment variables [loaded by Vite](https://vitejs.dev/guide/env-and-mode.html#env-files) from `.env` files and `process.env`. Like [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private), this module cannot be imported into client-side code. This module only includes variables that _do not_ begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) _and do_ start with [`config.kit.env.privatePrefix`](https://svelte.dev/docs/kit/configuration#env) (if configured).
 * 
 * _Unlike_ [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private), the values exported from this module are statically injected into your bundle at build time, enabling optimisations like dead code elimination.
 * 
 * ```ts
 * import { API_KEY } from '$env/static/private';
 * ```
 * 
 * Note that all environment variables referenced in your code should be declared (for example in an `.env` file), even if they don't have a value until the app is deployed:
 * 
 * ```
 * MY_FEATURE_FLAG=""
 * ```
 * 
 * You can override `.env` values from the command line like so:
 * 
 * ```bash
 * MY_FEATURE_FLAG="enabled" npm run dev
 * ```
 */
declare module '$env/static/private' {
	export const PROMPT: string;
	export const NODE_ENV: string;
	export const SYSTEMDRIVE: string;
	export const HOMEPATH: string;
	export const PLINK_PROTOCOL: string;
	export const TERM: string;
	export const WINDIR: string;
	export const MSYSTEM_CHOST: string;
	export const CHROME_CRASHPAD_PIPE_NAME: string;
	export const PROCESSOR_LEVEL: string;
	export const ONEDRIVE: string;
	export const PROCESSOR_ARCHITECTURE: string;
	export const TERM_PROGRAM_VERSION: string;
	export const VSCODE_GIT_ASKPASS_NODE: string;
	export const VSCODE_GIT_ASKPASS_MAIN: string;
	export const VSCODE_GIT_IPC_HANDLE: string;
	export const PROCESSOR_REVISION: string;
	export const EFC_11708: string;
	export const CONFIG_SITE: string;
	export const MANPATH: string;
	export const ZES_ENABLE_SYSMAN: string;
	export const LANG: string;
	export const LOGONSERVER: string;
	export const ALLUSERSPROFILE: string;
	export const PUBLIC: string;
	export const TERM_PROGRAM: string;
	export const CHOCOLATEYLASTPATHUPDATE: string;
	export const PKG_CONFIG_SYSTEM_INCLUDE_PATH: string;
	export const COMSPEC: string;
	export const MSYSTEM_CARCH: string;
	export const SSH_ASKPASS: string;
	export const USERPROFILE: string;
	export const PS1: string;
	export const INFOPATH: string;
	export const IGCCSVC_DB: string;
	export const ONEDRIVECONSUMER: string;
	export const ACLOCAL_PATH: string;
	export const ORIGINAL_TEMP: string;
	export const ORIGINAL_TMP: string;
	export const USERNAME: string;
	export const HOMEDRIVE: string;
	export const COMPUTERNAME: string;
	export const OLDPWD: string;
	export const PROGRAMFILES: string;
	export const SHLVL: string;
	export const OS: string;
	export const USERDOMAIN: string;
	export const TMPDIR: string;
	export const MSYS: string;
	export const MSYSTEM_PREFIX: string;
	export const EXEPATH: string;
	export const SESSIONNAME: string;
	export const HOME: string;
	export const COMMONPROGRAMW6432: string;
	export const PSMODULEPATH: string;
	export const USERDOMAIN_ROAMINGPROFILE: string;
	export const COMMONPROGRAMFILES: string;
	export const DRIVERDATA: string;
	export const APPDATA: string;
	export const MINGW_CHOST: string;
	export const PROGRAMW6432: string;
	export const TEMP: string;
	export const MINGW_PACKAGE_PREFIX: string;
	export const PATHEXT: string;
	export const DISPLAY: string;
	export const CHOCOLATEYINSTALL: string;
	export const ORIGINAL_XDG_CURRENT_DESKTOP: string;
	export const SHELL: string;
	export const NUMBER_OF_PROCESSORS: string;
	export const PWD: string;
	export const INIT_CWD: string;
	export const HOSTNAME: string;
	export const PROCESSOR_IDENTIFIER: string;
	export const SYSTEMROOT: string;
	export const LOCALAPPDATA: string;
	export const MINGW_PREFIX: string;
	export const MSYSTEM: string;
	export const PKG_CONFIG_PATH: string;
	export const ORIGINAL_PATH: string;
	export const TMP: string;
	export const PATH: string;
	export const PROGRAMDATA: string;
	export const PKG_CONFIG_SYSTEM_LIBRARY_PATH: string;
	export const GIT_ASKPASS: string;
	export const COLORTERM: string;
	export const _: string;
}

/**
 * Similar to [`$env/static/private`](https://svelte.dev/docs/kit/$env-static-private), except that it only includes environment variables that begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) (which defaults to `PUBLIC_`), and can therefore safely be exposed to client-side code.
 * 
 * Values are replaced statically at build time.
 * 
 * ```ts
 * import { PUBLIC_BASE_URL } from '$env/static/public';
 * ```
 */
declare module '$env/static/public' {
	
}

/**
 * This module provides access to runtime environment variables, as defined by the platform you're running on. For example if you're using [`adapter-node`](https://github.com/sveltejs/kit/tree/main/packages/adapter-node) (or running [`vite preview`](https://svelte.dev/docs/kit/cli)), this is equivalent to `process.env`. This module only includes variables that _do not_ begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) _and do_ start with [`config.kit.env.privatePrefix`](https://svelte.dev/docs/kit/configuration#env) (if configured).
 * 
 * This module cannot be imported into client-side code.
 * 
 * Dynamic environment variables cannot be used during prerendering.
 * 
 * ```ts
 * import { env } from '$env/dynamic/private';
 * console.log(env.DEPLOYMENT_SPECIFIC_VARIABLE);
 * ```
 * 
 * > In `dev`, `$env/dynamic` always includes environment variables from `.env`. In `prod`, this behavior will depend on your adapter.
 */
declare module '$env/dynamic/private' {
	export const env: {
		PROMPT: string;
		NODE_ENV: string;
		SYSTEMDRIVE: string;
		HOMEPATH: string;
		PLINK_PROTOCOL: string;
		TERM: string;
		WINDIR: string;
		MSYSTEM_CHOST: string;
		CHROME_CRASHPAD_PIPE_NAME: string;
		PROCESSOR_LEVEL: string;
		ONEDRIVE: string;
		PROCESSOR_ARCHITECTURE: string;
		TERM_PROGRAM_VERSION: string;
		VSCODE_GIT_ASKPASS_NODE: string;
		VSCODE_GIT_ASKPASS_MAIN: string;
		VSCODE_GIT_IPC_HANDLE: string;
		PROCESSOR_REVISION: string;
		EFC_11708: string;
		CONFIG_SITE: string;
		MANPATH: string;
		ZES_ENABLE_SYSMAN: string;
		LANG: string;
		LOGONSERVER: string;
		ALLUSERSPROFILE: string;
		PUBLIC: string;
		TERM_PROGRAM: string;
		CHOCOLATEYLASTPATHUPDATE: string;
		PKG_CONFIG_SYSTEM_INCLUDE_PATH: string;
		COMSPEC: string;
		MSYSTEM_CARCH: string;
		SSH_ASKPASS: string;
		USERPROFILE: string;
		PS1: string;
		INFOPATH: string;
		IGCCSVC_DB: string;
		ONEDRIVECONSUMER: string;
		ACLOCAL_PATH: string;
		ORIGINAL_TEMP: string;
		ORIGINAL_TMP: string;
		USERNAME: string;
		HOMEDRIVE: string;
		COMPUTERNAME: string;
		OLDPWD: string;
		PROGRAMFILES: string;
		SHLVL: string;
		OS: string;
		USERDOMAIN: string;
		TMPDIR: string;
		MSYS: string;
		MSYSTEM_PREFIX: string;
		EXEPATH: string;
		SESSIONNAME: string;
		HOME: string;
		COMMONPROGRAMW6432: string;
		PSMODULEPATH: string;
		USERDOMAIN_ROAMINGPROFILE: string;
		COMMONPROGRAMFILES: string;
		DRIVERDATA: string;
		APPDATA: string;
		MINGW_CHOST: string;
		PROGRAMW6432: string;
		TEMP: string;
		MINGW_PACKAGE_PREFIX: string;
		PATHEXT: string;
		DISPLAY: string;
		CHOCOLATEYINSTALL: string;
		ORIGINAL_XDG_CURRENT_DESKTOP: string;
		SHELL: string;
		NUMBER_OF_PROCESSORS: string;
		PWD: string;
		INIT_CWD: string;
		HOSTNAME: string;
		PROCESSOR_IDENTIFIER: string;
		SYSTEMROOT: string;
		LOCALAPPDATA: string;
		MINGW_PREFIX: string;
		MSYSTEM: string;
		PKG_CONFIG_PATH: string;
		ORIGINAL_PATH: string;
		TMP: string;
		PATH: string;
		PROGRAMDATA: string;
		PKG_CONFIG_SYSTEM_LIBRARY_PATH: string;
		GIT_ASKPASS: string;
		COLORTERM: string;
		_: string;
		[key: `PUBLIC_${string}`]: undefined;
		[key: `${string}`]: string | undefined;
	}
}

/**
 * Similar to [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private), but only includes variables that begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) (which defaults to `PUBLIC_`), and can therefore safely be exposed to client-side code.
 * 
 * Note that public dynamic environment variables must all be sent from the server to the client, causing larger network requests — when possible, use `$env/static/public` instead.
 * 
 * Dynamic environment variables cannot be used during prerendering.
 * 
 * ```ts
 * import { env } from '$env/dynamic/public';
 * console.log(env.PUBLIC_DEPLOYMENT_SPECIFIC_VARIABLE);
 * ```
 */
declare module '$env/dynamic/public' {
	export const env: {
		[key: `PUBLIC_${string}`]: string | undefined;
	}
}
