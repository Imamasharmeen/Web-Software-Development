<script>
  export let question;
  import { createEventDispatcher } from 'svelte';
  const dispatch = createEventDispatcher();

  function upvote() {
    dispatch('upvoteQuestion', question.id);
  }
  function del() {
    dispatch('deleteQuestion', question.id);
  }
</script>

<div class="question">
  <h3>{question.title}</h3>
  <p>{question.text}</p>
  <p>Upvotes: {question.upvotes}</p>
  <button on:click={upvote}>Upvote</button>
  <button on:click={del}>Delete</button>
</div>