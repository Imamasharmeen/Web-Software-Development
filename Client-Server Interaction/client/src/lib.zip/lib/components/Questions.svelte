<script>
  import { onMount } from 'svelte';
  import QuestionForm from './QuestionForm.svelte';
  import QuestionList from './QuestionList.svelte';

  let questions = [];
  let loading = true;
  let error = '';
  const API_BASE = 'http://localhost:8001';

  async function fetchQuestions() {
  try {
    loading = true;
    console.log('Fetching questions...'); // Debugging
    const response = await fetch(`${API_BASE}/courses/1/questions`);
    console.log('Response:', response); // Debugging
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    questions = await response.json();
    console.log('Questions:', questions); // Debugging
    error = '';
  } catch (err) {
    console.error('Fetch error:', err); // Debugging
    error = `Failed to fetch questions: ${err.message}`;
    questions = [];
  } finally {
    loading = false;
  }
}



  async function handleAddQuestion(event) {
    const { title, text } = event.detail;
    try {
      const response = await fetch(`${API_BASE}/courses/1/questions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, text }),
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      await fetchQuestions();
    } catch (err) {
      error = `Failed to add question: ${err.message}`;
    }
  }

  async function handleUpvoteQuestion(event) {
    const qId = event.detail;
    try {
      const response = await fetch(`${API_BASE}/courses/1/questions/${qId}/upvote`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      await fetchQuestions();
    } catch (err) {
      error = `Failed to upvote question: ${err.message}`;
    }
  }

  async function handleDeleteQuestion(event) {
    const qId = event.detail;
    try {
      const response = await fetch(`${API_BASE}/courses/1/questions/${qId}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      await fetchQuestions();
    } catch (err) {
      error = `Failed to delete question: ${err.message}`;
    }
  }

  onMount(fetchQuestions);
</script>

<div>
  <h2>Questions</h2>
  {#if loading}
    <p>Loading questions...</p>
  {:else if error}
    <p class="error">{error}</p>
  {:else}
    <QuestionForm on:addQuestion={handleAddQuestion} />
    <QuestionList
      {questions}
      on:upvoteQuestion={handleUpvoteQuestion}
      on:deleteQuestion={handleDeleteQuestion}
    />
  {/if}
</div>

<style>
  h2 {
    margin-bottom: 1rem;
  }
  .error {
    color: red;
    margin-bottom: 1rem;
  }
</style>