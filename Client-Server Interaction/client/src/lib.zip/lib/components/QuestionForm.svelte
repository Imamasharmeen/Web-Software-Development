<script>
  import { createEventDispatcher } from 'svelte';
  const dispatch = createEventDispatcher();

  let title = '';
  let text = '';

  async function handleSubmit() {
    if (title.trim() && text.trim()) {
      await dispatch('addQuestion', { title, text });
      title = '';
      text = '';
    }
  }
</script>

<form on:submit|preventDefault={handleSubmit}>
  <div>
    <label for="title">Title</label>
    <input id="title" name="title" type="text" bind:value={title} required />
  </div>
  <div>
    <label for="text">Question Text</label>
    <textarea id="text" name="text" bind:value={text} required></textarea>
  </div>
  <button type="submit">Add Question</button>
</form>

<style>
  div {
    margin-bottom: 1rem;
  }
  label {
    display: block;
    margin-bottom: 0.5rem;
  }
  input,
  textarea {
    width: 100%;
    padding: 0.5rem;
    border: 1px solid #ccc;
    border-radius: 4px;
  }
  textarea {
    height: 100px;
    resize: vertical;
  }
  button {
    padding: 0.5rem 1rem;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  button:hover {
    background-color: #0056b3;
  }
</style>