<script>
  import Questions from '$lib/components/Questions.svelte';
</script>

<main>
  <Questions />
</main>

<style>
  main {
    max-width: 800px;
    margin: 0 auto;
    padding: 1rem;
  }
</style>