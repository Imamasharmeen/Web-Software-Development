<script>
    import TodoForm from "./TodoForm.svelte";
    import TodoItem from "./TodoItem.svelte";
  
    let todos = $state([]);
  
    const removeTodo = (todo) => {
      todos = todos.filter((t) => t.id !== todo.id);
    };
  </script>
  
  <h1>Todos</h1>
  
  <h2>Add Todo</h2>
  
  <TodoForm {todos} />
  
  <h2>Existing todos</h2>
  
  <ul>
    {#each todos as todo}
      <li>
        <TodoItem {todo} {removeTodo} />
      </li>
    {/each}
  </ul>