<script>
    import QuestionForm from "./QuestionForm.svelte";
    import QuestionList from "./QuestionList.svelte";
  </script>
  
  <h1>Questions</h1>
  <QuestionForm />
  <QuestionList />