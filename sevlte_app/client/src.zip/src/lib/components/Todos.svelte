<script>
	import TodoForm from "./TodoForm.svelte";
	import TodoList from "./TodoList.svelte";
</script>

<section class="space-y-6">
	<TodoForm />
	<TodoList />
</section>
